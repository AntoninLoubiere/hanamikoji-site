Téléverser un champion sur le serveur

Si vous avez 'make' déjà installé, il vous suffit de lancer la commande 'make tar' dans le dossier pour obtenir l'archive. Sinon, il suffit créer une archive avec tous les fichiers du dossier (les fichiers Makefile et Makefile-<langage> ne sont pas nécessaire par contre), si le serveur ne détecte pas le langage, vous pouvez ajouter un fichier texte nommé _lang avec le nom du langage dedans (i.e. le nom du dossier de l'archive). Une fois l'archive obtenue, vous pouvez la téléverser sur le serveur sur la page 'Ajouter un champion'.

Lancer un match
Une fois que les champions ont été téléversés et que le serveur a terminé de compilé votre code, il suffit de se rendre sur la page 'Lancer un match'