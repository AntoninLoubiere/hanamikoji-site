#include "api.hh"

/// Fonction appelée au début du jeu
void init_jeu()
{
    // TODO
}

/// Fonction appelée au début du tour
void jouer_tour()
{
    // TODO
}

/// Fonction appelée lors du choix entre les trois cartes lors de l'action de
/// l'adversaire (cf tour_precedent)
void repondre_action_choix_trois()
{
    // TODO
}

/// Fonction appelée lors du choix entre deux paquets lors de l'action de
/// l'adversaire (cf tour_precedent)
void repondre_action_choix_paquets()
{
    // TODO
}

/// Fonction appelée à la fin du jeu
void fin_jeu()
{
    // TODO
}
