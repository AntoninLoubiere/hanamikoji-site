from api import *


# Fonction appelée au début du jeu
def init_jeu():
    # TODO
    pass


# Fonction appelée au début du tour
def jouer_tour():
    # TODO
    pass


# Fonction appelée lors du choix entre les trois cartes lors de l'action de
# l'adversaire (cf tour_precedent)
def repondre_action_choix_trois():
    # TODO
    pass


# Fonction appelée lors du choix entre deux paquets lors de l'action de
# l'adversaire (cf tour_precedent)
def repondre_action_choix_paquets():
    # TODO
    pass


# Fonction appelée à la fin du jeu
def fin_jeu():
    # TODO
    pass
