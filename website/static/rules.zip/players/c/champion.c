#include "api.h"

// Fonction appelée au début du jeu
void init_jeu(void)
{
    // TODO
}

// Fonction appelée au début du tour
void jouer_tour(void)
{
    // TODO
}

// Fonction appelée lors du choix entre les trois cartes lors de l'action de
// l'adversaire (cf tour_precedent)
void repondre_action_choix_trois(void)
{
    // TODO
}

// Fonction appelée lors du choix entre deux paquet lors de l'action de
// l'adversaire (cf tour_precedent)
void repondre_action_choix_paquets(void)
{
    // TODO
}

// Fonction appelée à la fin du jeu
void fin_jeu(void)
{
    // TODO
}
